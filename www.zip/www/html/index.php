<?php
require_once __DIR__ . "/private/auth.php";
require_once __DIR__ . "/private/db.php";
require_login(); // otomatis redirect ke login kalau belum login
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manajemen OLT &amp; Bot Tele"</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <?php include __DIR__ . '/dist/navbar.php'; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include __DIR__ . '/dist/sidebar.php'; ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-server"></i></span>
                <?php
                    // Hitung total OLT
                    $total_olt = $pdo->query("SELECT COUNT(*) FROM olt")->fetchColumn();
                    ?>
              <div class="info-box-content">
                <span class="info-box-text">TOTAL OLT</span>
                <span class="info-box-number">
                  <?= $total_olt ?>
                  <!--<small>%</small> -->
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-network-wired"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">TOTAL ONU</span>
                <span class="info-box-number" id="total-onu">0</span> <!-- Akan diisi via JS -->
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-check"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Onu Online</span>
                <span class="info-box-number" id="online-onu">0</span> <!-- Akan diisi via JS -->
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-user-slash"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Onu Offline</span>
                <span class="info-box-number" id="offline-onu">0</span> <!-- Akan diisi via JS -->
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <div class="row">
        <!-- data donut -->
         <div class="col-6 col-md-6 col-12">
            <div class="card card-info">
            <!-- DONUT CHART -->
              <div class="card-header">
                <h3 class="card-title">Status OLT</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                                <!-- /.card-header -->
              <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>OLT</th>
                      <th>IP</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $stmt = $pdo->query("SELECT * FROM olt ORDER BY id ASC");
                    $no = 1;
                    foreach ($stmt as $row): ?>
                      <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['hostname']) ?></td>
                        <td><?= htmlspecialchars($row['ip']) ?></td>
                        <td>
                          <span 
                            class="badge bg-secondary status-badge" 
                            data-ip="<?= htmlspecialchars($row['ip']) ?>">
                            Checking...
                          </span>
                        </td>
                        <td>
                          <!-- Tombol REFRESH -->
                          <button 
                            type="button" 
                            class="btn btn-warning btn-sm btn-refresh-olt"
                            data-ip="<?= htmlspecialchars($row['ip']) ?>">
                            <i class="fa-solid fa-rotate"></i>
                          </button>

                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              <!-- /.card-body -->
              </div>
              <!-- /.card-body -->
            </div>
            </div>
            </div>
            <!-- /.card -->
            <!-- DONUT CHART -->
            <div class="col-6 col-md-6 col-12">
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Onu Status</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="donutChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
        </div>
        </div>
            <!-- /.card -->

        <!-- end data donut -->  
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">ONU DATA</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
                  <div class="card-body">
                      <div class="row mb-1">
                          <div class="col-md-1">
                            <label>Status</label>
                            <select id="filterStatus" class="form-control">
                              <option value="">All</option>
                              <option value="Online">Online</option>
                              <option value="Offline">Offline</option>
                            </select>
                          </div>
                        <div class="col-md-1">
                          <label>OLT</label>
                          <select id="filterOlt" class="form-control">
                            <option value="">All</option>
                            <?php 
                              $stmt = $pdo->query("SELECT * FROM olt ORDER BY id ASC");
                              foreach ($stmt as $row): 
                            ?>
                              <option value="<?= htmlspecialchars($row['hostname']) ?>">
                                <?= htmlspecialchars($row['hostname']) ?>
                              </option>
                            <?php endforeach; ?>
                          </select>
                        </div>
                          <div class="col-md-1">
                            <label>Refresh Data</label>
                            <button type="button" id="btn-refresh-onu" class="btn btn-block btn-primary">
                              REFRESH
                            </button>
                          </div>
                        </div>
                    <table id="DataOnu" class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>OLT</th>
                          <th>NAMA</th>
                          <th>MAC</th>
                          <th>ONU RX-POWER</th>
                          <th>STATUS</th>
                          <th>REGISTER TIME</th>
                          <th>LATS DOWN TIME</th>
                          <th>LATS DOWN REASON</th>
                          <th>VENDOR</th>  
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                    </table>
                  </div>
              <!-- /.card-body -->
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- footer -->
  <?php include __DIR__ . '/dist/footer.php'; ?>
  <!-- end footer -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="../../plugins/chart.js/Chart.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/jszip/jszip.min.js"></script>
<script src="../../plugins/pdfmake/pdfmake.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<script>
    $(document).ready(function() {
        // Variabel global untuk chart
        var donutChart = null;

        // Fungsi untuk update donut chart
        function updateDonutChart(online, offline) {
            var donutChartCanvas = $('#donutChart').get(0).getContext('2d');
            var donutData = {
                labels: ['Offline', 'Online'],
                datasets: [{
                    data: [offline, online],
                    backgroundColor: ['#f56954', '#00a65a'],
                }]
            };
            var donutOptions = {
                maintainAspectRatio: false,
                responsive: true,
            };

            if (donutChart) {
                donutChart.destroy();
            }

            donutChart = new Chart(donutChartCanvas, {
                type: 'doughnut',
                data: donutData,
                options: donutOptions
            });
        }

        // Inisialisasi chart dengan nilai default
        updateDonutChart(0, 0);

        // Fungsi untuk check status OLT
        $(".status-badge").each(function() {
            const badge = $(this);
            const ip = badge.data("ip");

            $.get("/private/ping.php", { ip: ip }, function(res) {
                if (res.status === "ONLINE") {
                    badge.removeClass("bg-secondary").addClass("bg-success").text("ONLINE");
                } else {
                    badge.removeClass("bg-secondary").addClass("bg-danger").text("OFFLINE");
                }
            }, "json").fail(function() {
                badge.removeClass("bg-secondary").addClass("bg-dark").text("ERROR");
            });
        });

        // Event handler untuk refresh OLT
        $(document).on('click', '.btn-refresh-olt', function() {
            const btn = $(this);
            const ip = btn.data('ip');
            const row = btn.closest('tr');
            const badge = row.find('.status-badge');

            // Set UI ke Checking
            badge
                .removeClass('bg-success bg-danger bg-dark')
                .addClass('bg-secondary')
                .text('Checking...');
            btn.prop('disabled', true);

            // Panggil ping.php
            $.get('/private/ping.php', { ip: ip }, function(res) {
                if (res.status === 'ONLINE') {
                    badge
                        .removeClass('bg-secondary')
                        .addClass('bg-success')
                        .text('ONLINE');
                } else {
                    badge
                        .removeClass('bg-secondary')
                        .addClass('bg-danger')
                        .text('OFFLINE');
                }
            }, 'json')
            .fail(function() {
                badge
                    .removeClass('bg-secondary')
                    .addClass('bg-dark')
                    .text('ERROR');
            })
            .always(function() {
                btn.prop('disabled', false);
            });
        });

        // Inisialisasi DataTable
        var dataTable = $("#DataOnu").DataTable({
            "responsive": true,
            "lengthChange": true,
            "autoWidth": false,
            "searching": true,
            "paging": true,
            "ordering": true,
            "lengthMenu": [[10, 25, 50, 100, 500], [10, 25, 50, 100, 500]], // Tambahkan opsi 500
            "pageLength": 10, // Default tampilan 100 entries
            "data": [],
            "columns": [
                { 
                    "data": null,
                    "render": function(data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                { "data": "olt" },
                { "data": "name" },
                { "data": "mac" },
                
            { 
            "data": "rx_power",
            "render": function(data, type, row) {
                if (data === null || data === undefined || data === "N/A" || data === "" || data === "offline") {
                    return '<span class="badge bg-danger">NONE</span>';
                } else {
                    var rxValue = parseFloat(data);
                    if (!isNaN(rxValue)) {
                        // Kondisi berdasarkan nilai RX power
                        if (rxValue > -3) {
                            // Lebih dari -3 dBm (terlalu tinggi) - Warning
                            return '<span class="badge bg-warning">' + rxValue.toFixed(2) + ' dBm</span>';
                        } else if (rxValue >= -25 && rxValue <= -3) {
                            // Normal: antara -25 dBm sampai -3 dBm - Success
                            return '<span class="badge bg-success">' + rxValue.toFixed(2) + ' dBm</span>';
                        } else if (rxValue < -25) {
                            // Kurang dari -25 dBm (terlalu rendah) - Warning
                            return '<span class="badge bg-warning">' + rxValue.toFixed(2) + ' dBm</span>';
                        } else {
                            // Untuk nilai lainnya (jika ada)
                            return '<span class="badge bg-secondary">' + rxValue.toFixed(2) + ' dBm</span>';
                        }
                    } else {
                        return '<span class="badge bg-danger">NONE</span>';
                    }
                }
            }
        },
                { 
                    "data": "status",
                    "render": function(data, type, row) {
                        if (!data) return '<span class="badge bg-danger">OFFLINE</span>';

                        var statusUpper = data.toUpperCase();
                        if (statusUpper === 'ONLINE') {
                            return '<span class="badge bg-success">ONLINE</span>';
                        } else {
                            return '<span class="badge bg-danger">OFFLINE</span>';
                        }
                    }
                },
                { 
    "data": "register_time",
    "render": function(data, type, row) {
        return data && data !== 'N/A' ? data : '<span class="badge bg-secondary">Unknown</span>';
    }
},
{ 
    "data": "last_down_time",
    "render": function(data, type, row) {
        return data && data !== 'N/A' ? data : '<span class="badge bg-secondary">Never</span>';
    }
},
{ 
    "data": "last_down_reason",
    "render": function(data, type, row) {
        return data && data !== 'N/A' ? data : '<span class="badge bg-secondary">N/A</span>';
    }
},
{ 
    "data": "vendor",
    "render": function(data, type, row) {
        return data && data !== 'N/A' ? data : '<span class="badge bg-secondary">Unknown</span>';
    }
}

            ]
        });

        // Fungsi untuk memuat data ONU
        function loadOnuData() {
            $('#table-loading').show();

            $.get('/private/onu_api.php?action=get_onu_data', function(response) {
                if (response && response.data) {
                    // clear table dulu
                    dataTable.clear();

                    // tambah data baru
                    dataTable.rows.add(response.data).draw();

                    // Hitung total, online, offline
                    var totalOnu = response.data.length;
                    var onlineOnu = response.data.filter(function(item) {
                        return item.status && item.status.toUpperCase() === 'ONLINE';
                    }).length;
                    var offlineOnu = totalOnu - onlineOnu;

                    // Update info box
                    $('#total-onu').text(totalOnu);
                    $('#online-onu').text(onlineOnu);
                    $('#offline-onu').text(offlineOnu);

                    // Update donut chart
                    updateDonutChart(onlineOnu, offlineOnu);

                } else {
                    alert('Tidak ada data ONU yang ditemukan');
                    dataTable.clear().draw();
                    updateDonutChart(0, 0);
                }
                $('#table-loading').hide();
            }, 'json').fail(function() {
                alert('Gagal memuat data ONU.');
                dataTable.clear().draw();
                updateDonutChart(0, 0);
                $('#table-loading').hide();
            });
        }

        // Filter data berdasarkan status
        $('#filterStatus').on('change', function() {
            var statusFilter = $(this).val();
            
            if (statusFilter === '') {
                dataTable.column(5).search('').draw();
            } else {
                dataTable.column(5).search('^' + statusFilter + '$', true, false).draw();
            }
        });

        // Filter data berdasarkan OLT
        $('#filterOlt').on('change', function() {
            var oltFilter = $(this).val();
            
            if (oltFilter === '') {
                dataTable.column(1).search('').draw();
            } else {
                dataTable.column(1).search(oltFilter).draw();
            }
        });

        // Tombol refresh
        $('#btn-refresh-onu').on('click', function() {
            loadOnuData();
        });

        // Muat data ONU saat halaman pertama kali dibuka
        loadOnuData();
$('#DataOnu tbody').on('click', 'tr', function (e) {
    // Cek apakah klik di cell expand (responsive control)
    if ($(e.target).closest('td').hasClass('dtr-control')) {
        return; // biarkan DataTables expand, jangan redirect
    }

    var rowData = dataTable.row(this).data();
    if (rowData && rowData.mac) {
        window.location.href = "onu-detail.php?mac=" + encodeURIComponent(rowData.mac);
    }
});

    });


</script>
</body>
</html>