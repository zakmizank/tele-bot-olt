<?php
require_once __DIR__ . "/private/auth.php";
require_once __DIR__ . "/private/db.php";
require_login(); // otomatis redirect ke login kalau belum login
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manajemen OLT &amp; Bot Tele"</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <?php include __DIR__ . '/dist/navbar.php'; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include __DIR__ . '/dist/sidebar.php'; ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
                  <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">ONU DATA</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
                  <div class="card-body">
                      <div class="row mb-1">
                          <div class="col-md-1">
                            <label>Status</label>
                            <select id="filterStatus" class="form-control">
                              <option value="">All</option>
                              <option value="Online">Online</option>
                              <option value="Offline">Offline</option>
                            </select>
                          </div>
                          <div class="col-md-1">
                            <label>OLT</label>
                            <select id="filterStatus" class="form-control">
                              <option value="">All</option>
                              <option value="Online">OLT-JETAK</option>
                              <option value="Offline">OLT-POJOK-1</option>
                            </select>
                          </div>
                          <div class="col-md-1">
                            <label>ADD OLT</label>
                            <button type="button" class="btn btn-block btn-success" data-toggle="modal" data-target="#modalAddOlt">ADD</button>
                          </div>
                        </div>
                    <table id="DataOlt" class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>HOST NAME</th>
                          <th>IP ADDRESS</th>
                          <th>STATUS</th>
                          <th>ACTION</th>
                        </tr>
                      </thead>
                    <tbody>
                    <?php 
                    $stmt = $pdo->query("SELECT * FROM olt ORDER BY id ASC");
                    $no = 1;
                    foreach ($stmt as $row): ?>
                      <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['hostname']) ?></td>
                        <td><?= htmlspecialchars($row['ip']) ?></td>
                        <td>
                          <span 
                            class="badge bg-secondary status-badge" 
                            data-ip="<?= htmlspecialchars($row['ip']) ?>">
                            Checking...
                          </span>
                        </td>
                        <td>
                          <button 
                            type="button" 
                            class="btn btn-info btn-sm btn-edit-olt" data-toggle="modal"
                            data-id="<?= $row['id'] ?>" data-target="#modalEditOlt">
                            <i class="fa-solid fa-pen-to-square"></i>
                          </button>

                          <!-- Tombol REFRESH -->
                          <button 
                            type="button" 
                            class="btn btn-warning btn-sm btn-refresh-olt"
                            data-ip="<?= htmlspecialchars($row['ip']) ?>">
                            <i class="fa-solid fa-rotate"></i>
                          </button>

                          <button 
                            type="button" 
                            class="btn btn-danger btn-sm btn-delete-olt"
                            data-id="<?= $row['id'] ?>">
                            <i class="fa-solid fa-trash-can"></i>
                          </button>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                    </tbody>
                    </table>
                  </div>
              <!-- /.card-body -->
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- Modal Add OLT -->
        <div class="modal fade" id="modalAddOlt" tabindex="-1" role="dialog" aria-labelledby="modalAddOltLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <form id="formAddOlt">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Tambah OLT Baru</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                      <label>Hostname</label>
                      <input type="text" class="form-control" name="hostname" required>
                    </div>
                    <div class="form-group">
                      <label>IP Address</label>
                      <input type="text" class="form-control" name="ip" required>
                    </div>
                    <div class="form-group">
                      <label>Username</label>
                      <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="form-group">
                      <label>Community Read</label>
                      <input type="text" class="form-control" name="community_read" required>
                    </div>
                    <div class="form-group">
                      <label>Community Write</label>
                      <input type="text" class="form-control" name="community_write" required>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                  <button type="submit" class="btn btn-success">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
     <!-- End Modal Add OLT -->
     <!-- Modal Edit OLT -->
        <div class="modal fade" id="modalEditOlt" tabindex="-1" role="dialog" aria-labelledby="modalEditOltLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <form id="formEditOlt">
                <input type="hidden" name="id">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Tambah OLT Baru</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                      <label>Hostname</label>
                      <input type="text" class="form-control" name="hostname" required>
                    </div>
                    <div class="form-group">
                      <label>IP Address</label>
                      <input type="text" class="form-control" name="ip" required>
                    </div>
                    <div class="form-group">
                      <label>Username</label>
                      <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="form-group">
                      <label>Community Read</label>
                      <input type="text" class="form-control" name="community_read" required>
                    </div>
                    <div class="form-group">
                      <label>Community Write</label>
                      <input type="text" class="form-control" name="community_write" required>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                  <button type="submit" class="btn btn-success">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
     <!-- End Modal Edit OLT -->

        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- footer -->
  <?php include __DIR__ . '/dist/footer.php'; ?>
  <!-- end footer -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="../../plugins/chart.js/Chart.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/jszip/jszip.min.js"></script>
<script src="../../plugins/pdfmake/pdfmake.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<script>
$(document).ready(function() {
  $(".status-badge").each(function() {
    const badge = $(this);
    const ip = badge.data("ip");

    $.get("/private/ping.php", { ip: ip }, function(res) {
      if (res.status === "ONLINE") {
        badge.removeClass("bg-secondary").addClass("bg-success").text("ONLINE");
      } else {
        badge.removeClass("bg-secondary").addClass("bg-danger").text("OFFLINE");
      }
    }, "json").fail(function() {
      badge.removeClass("bg-secondary").addClass("bg-dark").text("ERROR");
    });
  });
});

  $(function () {
    // Init DataTable (nanti bisa dihubungkan dengan server-side ajax)
    var table = $("#DataOlt").DataTable({
      "responsive": true,
      "lengthChange": true,
      "autoWidth": false,
      "searching": true,
      "paging": true,
      "ordering": true
    });

    // Submit form Add OLT via ajax
$("#formAddOlt").on("submit", function(e){
    e.preventDefault();

    $.ajax({
        url: "/private/add_olt.php",
        type: "POST",
        data: $(this).serialize(),
        dataType: "json", // pastikan AJAX expect JSON
        success: function(res) {
            if(res.success){
                alert(res.message);

                // Tutup modal
                $("#modalAddOlt").modal("hide");

                // Reset form (opsional, biar bersih kalau dibuka lagi)
                $("#formAddOlt")[0].reset();

                // Refresh DataTable
                 location.reload();
            } else {
                alert("Error: " + res.message);
            }
        },
        error: function(xhr, status, error){
            console.error("AJAX Error:", xhr.responseText);
            alert("Gagal menyimpan data!");
        }
    });
});
        $(document).on('click', '.btn-refresh-olt', function() {
    const btn   = $(this);
    const ip    = btn.data('ip');
    const row   = btn.closest('tr');
    const badge = row.find('.status-badge');

    // Set UI ke Checking
    badge
      .removeClass('bg-success bg-danger bg-dark')
      .addClass('bg-secondary')
      .text('Checking...');
    btn.prop('disabled', true);

    // Panggil ping.php
    $.get('/private/ping.php', { ip: ip }, function(res) {
      if (res.status === 'ONLINE') {
        badge
          .removeClass('bg-secondary')
          .addClass('bg-success')
          .text('ONLINE');
      } else {
        badge
          .removeClass('bg-secondary')
          .addClass('bg-danger')
          .text('OFFLINE');
      }
    }, 'json')
    .fail(function() {
      badge
        .removeClass('bg-secondary')
        .addClass('bg-dark')
        .text('ERROR');
    })
    .always(function() {
      btn.prop('disabled', false);
    });
  });
    $(document).on('click', '.btn-delete-olt', function() {
    const btn = $(this);
    const id  = btn.data('id');
    const row = btn.closest('tr');

    // Konfirmasi user
    if (!confirm('Yakin ingin menghapus OLT ini?')) {
      return;
    }

    // Nonaktifkan tombol untuk mencegah klik ganda
    btn.prop('disabled', true);

    // AJAX ke delete_olt.php
    $.ajax({
      url: '/private/hapus_olt.php',
      type: 'POST',
      data: { id: id },
      dataType: 'json',
      success: function(res) {
        if (res.success) {
          alert(res.message);
          // Hapus baris dari DataTable
          // Jika pakai DataTable API:
          $('#DataOlt').DataTable()
            .row(row)
            .remove()
            .draw(false);

          // Jika tidak pakai DataTable API, bisa:
          // row.remove();
        } else {
          alert('Error: ' + res.message);
        }
      },
      error: function(xhr){
        console.error('AJAX Error:', xhr.responseText);
        alert('Gagal menghapus data!');
      },
      complete: function(){
        btn.prop('disabled', false);
      }
    });
  });
  });
$(document).on('click', '.btn-edit-olt', function () {
  const id = $(this).data('id');
  $.get('/private/get_olt.php', { id: id }, function (res) {
    if (res.success) {
      const data = res.data;
      $('#formEditOlt [name="id"]').val(id);
      $('#formEditOlt [name="hostname"]').val(data.hostname);
      $('#formEditOlt [name="ip"]').val(data.ip);
      $('#formEditOlt [name="username"]').val(data.username);
      $('#formEditOlt [name="password"]').val(data.password);
      $('#formEditOlt [name="community_read"]').val(data.community_read);
      $('#formEditOlt [name="community_write"]').val(data.community_write);
      $('#modalEditOlt .modal-title').text('Edit OLT');
      $('#modalEditOlt').modal('show');
    } else {
      alert(res.message);
    }
  }, 'json');
});
$('#formEditOlt').on('submit', function (e) {
  e.preventDefault();

  $.ajax({
    url: '/private/update_olt.php',
    type: 'POST',
    data: $(this).serialize(),
    dataType: 'json',
    success: function (res) {
      if (res.success) {
        alert(res.message);
        $('#modalEditOlt').modal('hide');
        $('#formEditOlt')[0].reset();
        location.reload(); // atau refresh tabel via AJAX
      } else {
        alert('Gagal update: ' + res.message);
      }
    },
    error: function (xhr) {
      console.error('AJAX Error:', xhr.responseText);
      alert('Terjadi kesalahan saat mengirim data!');
    }
  });
});
$('#modalEditOlt').on('hidden.bs.modal', function () {
  $('#formEditOlt')[0].reset();
  $('#formEditOlt [name="id"]').val('');
  $('#modalEditOlt .modal-title').text('Tambah OLT Baru');
});

</script>

</body>
</html>
