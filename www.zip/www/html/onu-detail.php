<?php
require_once __DIR__ . "/private/auth.php";
require_once __DIR__ . "/private/db.php";
require_login(); // otomatis redirect ke login kalau belum login
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manajemen OLT &amp; Bot Tele"</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- uPlot -->
  <link rel="stylesheet" href="../../plugins/uplot/uPlot.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
       <style>
        body {
            background-color: #f8f9fa;
            padding: 0px;
        }
        .card {
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
        }
        .zoom-instruction {
            font-size: 0.85rem;
            color: #6c757d;
            padding: 8px 12px;
            background-color: #f8f9fa;
            border-radius: 4px;
            margin-top: 15px;
            border-left: 4px solid #007bff;
        }
        .chart-container {
            position: relative;
            height: 400px;
            width: 100%;
            overflow: hidden;
        }
        #resetZoomBtn {
            margin-top: 10px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
        }
        .card-title {
            margin-bottom: 0;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <?php include __DIR__ . '/dist/navbar.php'; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include __DIR__ . '/dist/sidebar.php'; ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
                  <!-- /.row -->
        <div class="row">
          <div class="col-md-6">
            <!-- Default box -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">DETAIL ONU</h3>
                  
              </div>
              <div class="card-body">
              <div class="card-body" id="onu-detail">
                <p class="text-muted">Loading data...</p>
              </div>
              </div>
              <!-- /.card-body -->
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
            </div>
            <div class="col-md-6">
              <div class="card card-secondary">
                <div class="card-header">
                  <h3 class="card-title">Log Terbaru ONU</h3>
                </div>
                <div class="card-body">
                  <table id="onu-log-table" class="table table-sm table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>Waktu</th>
                        <th>Raw Log</th>
                        <th>Hostname</th>
                        <th>MAC Address</th>
                        <th>Created At</th>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- Data akan diisi via AJAX -->
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
        </div>
        <div class="row">
            <div class="col-md-12">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Receive Power (RX)</h3>
                    <div class="card-tools">
                    <button type="button" class="btn btn-block btn-warning" id="resetZoomBtn">
                            <i class="fas fa-sync-alt"></i> Reset Zoom
                        </button>
                </div>
                </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="rxChart"></canvas>
                        </div>
                        <div class="zoom-instruction">
                            <i class="fas fa-info-circle"></i> Gunakan scroll mouse untuk zoom in/out atau drag untuk melakukan panning. Klik "Reset Zoom" untuk mengembalikan ke tampilan semula.
                        </div>
                    </div>
              </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- footer -->
  <?php include __DIR__ . '/dist/footer.php'; ?>
  <!-- end footer -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="../../plugins/chart.js/Chart.minv5.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@1.2.1/dist/chartjs-plugin-zoom.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/jszip/jszip.min.js"></script>
<script src="../../plugins/pdfmake/pdfmake.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<script>
$(document).ready(function(){
    const urlParams = new URLSearchParams(window.location.search);
    const mac = urlParams.get('mac');

    if(mac){
        $.getJSON("/private/get_onu_detail.php", { mac: mac }, function(data){
            if(data.success){
                let onu = data.onu;
                let detailHtml = `
                <table class="table table-sm table-bordered">
                  <tr><th>MAC Address</th><td>${onu.macaddr}</td></tr>
                  <tr><th>ONU Name</th><td>${onu.onu_name}</td></tr>
                  <tr><th>OLT</th><td>${onu.olt_name} (ID ${onu.olt_id})</td></tr>
                  <tr><th>PON OLT/ID</th><td>${onu.port_id} /${onu.onu_id}</td></tr>
                  <tr><th>Status</th><td>${onu.status_badge}</td></tr>
                  <tr><th>Last Down Reason</th><td>${onu.last_down_reason ?? '-'}</td></tr>
                  <tr><th>Register Time</th><td>${onu.register_time}</td></tr>
                  <tr><th>Update Terakhir</th><td>${onu.created_at}</td></tr>
                  <tr><th>Total Down</th><td id="total-down">Menghitung...</td></tr>
                  <tr><th>SLA Uptime</th><td id="sla-uptime">Menghitung...</td></tr>
                </table>`;
                $("#onu-detail").html(detailHtml);

                // Ambil log tambahan untuk hitung Total Down & SLA
                $.getJSON("/private/get_onu_sla.php", { mac: mac }, function(logData){
                    if(logData.success){
                        let logs = logData.logs;
                        if(logs.length > 0){
                            // Urutkan log berdasarkan waktu
                            logs.sort((a, b) => new Date(a.log_time) - new Date(b.log_time));

                            let totalDownEvents = 0;
                            let uptime = 0;
                            let downtime = 0;

                            for(let i=0; i<logs.length-1; i++){
                                let current = logs[i];
                                let next = logs[i+1];

                                let start = new Date(current.log_time).getTime();
                                let end   = new Date(next.log_time).getTime();
                                let duration = (end - start) / 1000; // detik

                                if(current.raw_log.toLowerCase().includes("link up")){
                                    uptime += duration;
                                } else {
                                    downtime += duration;
                                    totalDownEvents++;
                                }
                            }

                            // Tambahkan interval terakhir sampai sekarang
                            let lastLog = logs[logs.length-1];
                            let lastTime = new Date(lastLog.log_time).getTime();
                            let now = new Date().getTime();
                            let lastDuration = (now - lastTime) / 1000;

                            if(lastLog.raw_log.toLowerCase().includes("link up")){
                                uptime += lastDuration;
                            } else {
                                downtime += lastDuration;
                                totalDownEvents++;
                            }

                            let totalTime = uptime + downtime;
                            let sla = totalTime > 0 ? ((uptime / totalTime) * 100).toFixed(2) + "%" : "N/A";

                            $("#total-down").text(totalDownEvents + " Kali");
                            $("#sla-uptime").text(sla);
                        } else {
                            $("#total-down").text("0 Kali");
                            $("#sla-uptime").text("100%");
                        }
                    } else {
                        $("#total-down").text("N/A");
                        $("#sla-uptime").text("N/A");
                    }
                });
            } else {
                $("#onu-detail").html("<p class='text-danger'>Data ONU tidak ditemukan</p>");
            }
        });
    } else {
        $("#onu-detail").html("<p class='text-danger'>MAC Address tidak diberikan</p>");
    }
});
$(document).ready(function(){
    const urlParams = new URLSearchParams(window.location.search);
    const mac = urlParams.get('mac');

    if(!mac){
        $("#onu-log-table tbody").html('<tr><td colspan="5" class="text-danger">MAC Address tidak diberikan</td></tr>');
        return;
    }

    $("#onu-log-table").DataTable({
        "ajax": {
            "url": "/private/get_onu_log.php",
            "type": "GET",
            "data": { mac: mac },
            "dataSrc": function(json){
                if(json.success){
                    return json.logs;
                } else {
                    return [];
                }
            }
        },
        "columns": [
            { "data": "log_time" },
            { "data": "raw_log" },
            { "data": "hostname" },
            { "data": "mac_address" },
            { "data": "created_at" }
        ],
        "order": [[0, "desc"]],
        "paging": true,
        "pageLength": 5,
        "lengthChange": false,
        "searching": false,
        "info": true,
        "scrollY": false
    });
});

</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const mac = urlParams.get('mac');

    if(!mac){
        document.getElementById('rxChart').closest('.card-body').innerHTML = 
            '<p class="text-danger">MAC Address tidak diberikan</p>';
        return;
    }

    // Ambil data RX nyata
    fetch(`/private/get_rx_chart.php?mac=${mac}`)
    .then(res => res.json())
    .then(json => {
        if(!json.success || !json.data || json.data.length === 0){
            document.getElementById('rxChart').closest('.chart-container').innerHTML = 
                '<p class="text-muted">Data RX Power belum tersedia</p>';
            return;
        }

        const chartData = json.data.map(d => ({
            x: new Date(d.created_at).getTime(),
            y: parseFloat(d.receive_power)
        }));

        const data = {
            datasets: [{
                label: 'RX Power (dBm)',
                data: chartData,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderWidth: 1,
                pointRadius: 0,
                fill: true,
                tension: 0.1
            }]
        };

        const config = {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'day',
                            tooltipFormat: 'dd MMM yyyy HH:mm',
                            displayFormats: { hour: 'HH:mm', day: 'dd MMM' }
                        },
                        title: { display: true, text: 'Waktu' }
                    },
                    y: {
                        title: { display: true, text: 'RX Power (dBm)' },
                        suggestedMin: -30,
                        suggestedMax: -10
                    }
                },
                plugins: {
                    zoom: {
                        pan: { enabled: true, mode: 'x', modifierKey: 'ctrl' },
                        zoom: { wheel: { enabled: true, speed: 0.1 }, pinch: { enabled: true }, mode: 'x' }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            title: function(context) {
                                const date = new Date(context[0].parsed.x);
                                return date.toLocaleString('id-ID', {
                                    day: '2-digit',
                                    month: 'short',
                                    year: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                });
                            }
                        }
                    },
                    legend: { display: true }
                },
                interaction: { mode: 'index', intersect: false }
            }
        };

        const ctx = document.getElementById('rxChart').getContext('2d');
        const rxChart = new Chart(ctx, config);

        document.getElementById('resetZoomBtn').addEventListener('click', function() {
            rxChart.resetZoom();
        });
    })
    .catch(err => {
        console.error(err);
        document.getElementById('rxChart').closest('.chart-container').innerHTML = 
            '<p class="text-danger">Gagal mengambil data RX Power</p>';
    });
});
</script>
</body>
</html>
